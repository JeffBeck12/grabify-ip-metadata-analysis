# Authorized lab evidence record

**Status: unfilled template. Do not treat placeholders as findings.**

| Field | Authorized test details |
| --- | --- |
| Test date and time zone | To be recorded |
| Scope and consent reference | Keep the private consent record outside this repository |
| Device ownership / authorization | To be recorded without identifying the participant |
| Browser and network conditions | To be recorded |
| Permitted data and retention period | To be recorded |
| Agreed destination | Use a sanitized description |
| Evidence files | Relative paths to redacted files |

## Observations

Record only fields actually seen. Distinguish the raw observation, its interpretation, and uncertainty. Do not publish live tracking URLs or dashboard access identifiers.

| Observation | Supporting evidence | Interpretation | Limitation |
| --- | --- | --- | --- |
| To be recorded | To be recorded | To be recorded | To be recorded |

## Defensive conclusion

Explain the exposure, relevant controls, and what the evidence cannot prove.

## Closure

Record redaction review and deletion of raw data according to the agreed retention period.
