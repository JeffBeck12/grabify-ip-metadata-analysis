# Screenshot guide

This folder contains no lab screenshots yet. Add only evidence from an authorized test.

Suggested filenames: `metadata-redacted.png` and `redirect-trace-redacted.png`.

Before publishing, permanently remove public IPs, location details, participant names, identifying timestamps, tracking codes, management URLs, tokens, and sensitive browser details. Flatten redactions into the exported image; do not rely on removable annotations. Review browser tabs and surrounding UI as well as the main content.

Label each screenshot with what was observed and its limitations. Link it from the root README using `docs/screenshots/<filename>`. Do not substitute staged images for real test evidence.
