# Overview visual provenance

The earlier conversation referenced `a_wide_infographic_style_readme_project_poster_ima.png`. That file was not mounted in this workspace and was not available as an attachment in the retrieved conversation.

This package therefore includes a newly drawn explanatory overview at `images/grabify-project-overview.png`. It is a diagram, not a lab screenshot. To use the original visual later, replace this PNG while preserving the filename; the README already references that relative path.
